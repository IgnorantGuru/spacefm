#ifndef _GO_DLG_H_
#define _GO_DLG_H_

#include "main-window.h"
#include <gtk/gtk.h>

G_BEGIN_DECLS

gboolean fm_go( FMMainWindow* parent );

G_END_DECLS

#endif

